# gamekit.render.backend
# 渲染后端抽象：Renderer 接口 + 两个实现。
#
#   TkRenderer —— 默认后端，跨平台，基于 tkinter Canvas（保留模式）。
#   GdiRenderer —— 高性能后端，Windows 专用，基于自研 GDI 内核（立即模式）。
#
# Game 只依赖 Renderer 接口：创建窗口、跑循环、画矩形/圆/线/文字、
# 读输入状态。选哪个后端由 Game(backend=...) 决定，游戏代码不感知。
#
# GDI 后端为 Windows 原生窗口 + BitBlt 双缓冲，性能远高于 tkinter；
# 代价是仅 Windows 可用（其他平台自动回落 tkinter）。

import time

from ..utils.color import to_color

# ======================================================================
# 颜色工具：任意 gamekit 颜色字符串 -> (r, g, b)
# ======================================================================

# 常用颜色名 -> RGB（GDI 后端需要；tkinter 颜色名全集太大，这里覆盖常用）
_NAME_RGB = {
    "red": (255, 0, 0), "green": (0, 128, 0), "blue": (0, 0, 255),
    "yellow": (255, 255, 0), "gold": (255, 215, 0), "orange": (255, 165, 0),
    "purple": (128, 0, 128), "violet": (238, 130, 238), "pink": (255, 192, 203),
    "magenta": (255, 0, 255), "cyan": (0, 255, 255), "aqua": (0, 255, 255),
    "white": (255, 255, 255), "black": (0, 0, 0), "gray": (128, 128, 128),
    "grey": (128, 128, 128), "lime": (0, 255, 0), "brown": (165, 42, 42),
    "skyblue": (135, 206, 235), "navy": (0, 0, 128), "silver": (192, 192, 192),
    "maroon": (128, 0, 0), "olive": (128, 128, 0), "teal": (0, 128, 128),
    "indigo": (75, 0, 130), "coral": (255, 127, 80), "salmon": (250, 128, 114),
    "tomato": (255, 99, 71), "crimson": (220, 20, 60), "chocolate": (210, 105, 30),
    "beige": (245, 245, 220), "khaki": (240, 230, 140), "turquoise": (64, 224, 208),
}


def _rgb(color):
    """把颜色字符串转为 (r, g, b)。支持 '#rrggbb' 与常用颜色名。"""
    if not color:
        return (255, 255, 255)
    s = str(color).strip()
    if s.startswith("#") and len(s) == 7:
        return (int(s[1:3], 16), int(s[3:5], 16), int(s[5:7], 16))
    if s.startswith("#") and len(s) == 4:
        return (int(s[1] * 2, 16), int(s[2] * 2, 16), int(s[3] * 2, 16))
    return _NAME_RGB.get(s.lower(), (255, 255, 255))


def _colorref(color):
    """颜色字符串 -> GDI COLORREF（0x00BBGGRR）。"""
    r, g, b = _rgb(color)
    return (b & 0xFF) | ((g & 0xFF) << 8) | ((r & 0xFF) << 16)


# ======================================================================
# Renderer 接口
# ======================================================================

class Renderer:
    """渲染后端接口。Game 与所有可绘制对象只调用这些方法。

    两个后端共享同一套绘制语义（坐标、颜色、锚点），但内部实现不同：
    tkinter 保留模式 vs GDI 立即模式。
    """

    # ---- 生命周期 ----
    def __init__(self, width, height, title, bg_color):
        raise NotImplementedError

    def run_loop(self, tick, frame_delay_ms):
        """启动阻塞式主循环。每帧调用 ``tick()``，两帧之间约等
        ``frame_delay_ms`` 毫秒。返回后循环结束。"""
        raise NotImplementedError

    def stop(self):
        raise NotImplementedError

    def close(self):
        raise NotImplementedError

    # ---- 每帧 ----
    def pump(self):
        """拉取事件 / 输入状态（键、鼠标）。每帧开头调用。"""
        raise NotImplementedError

    def begin_frame(self):
        """清屏并准备本帧绘制。"""
        raise NotImplementedError

    def end_frame(self):
        """完成本帧并翻屏。"""
        raise NotImplementedError

    # ---- 输入状态（每帧 pump 后刷新）----
    @property
    def keys_held(self):
        return set()

    @property
    def mouse_x(self):
        return 0

    @property
    def mouse_y(self):
        return 0

    @property
    def mouse_buttons(self):
        return set()

    def is_key_down(self, keysym):
        return keysym in self.keys_held

    def mouse_pos(self):
        return (self.mouse_x, self.mouse_y)

    # ---- 绘制原语（对象层调用）----
    def draw_rect(self, x1, y1, x2, y2, color, outline=None, width=1):
        raise NotImplementedError

    def draw_oval(self, x1, y1, x2, y2, color, outline=None, width=1):
        raise NotImplementedError

    def draw_line(self, x1, y1, x2, y2, color, width=2):
        raise NotImplementedError

    def draw_polygon(self, points, color, outline=None):
        raise NotImplementedError

    def draw_arc(self, x1, y1, x2, y2, start, extent, color, width=2):
        raise NotImplementedError

    def draw_image(self, x, y, image):
        raise NotImplementedError

    def draw_text(self, x, y, content, color, font, size, weight, slant, anchor):
        raise NotImplementedError


# ======================================================================
# TkRenderer —— 默认后端（跨平台，tkinter）
# ======================================================================

class TkRenderer(Renderer):
    """基于 tkinter Canvas 的后端。保留模式：对象画到 canvas，由 Tk 管理。

    该后端为默认选项，任何平台都能跑。事件由 Tk 的 bind 驱动，
    通过 Canvas/root 的 bind 回调更新输入状态。
    """

    def __init__(self, width, height, title, bg_color, resizable=False):
        import tkinter as tk
        self.width = int(width)
        self.height = int(height)
        self.root = tk.Tk()
        self.root.title(title)
        self.root.resizable(bool(resizable), bool(resizable))
        self.canvas = tk.Canvas(self.root, width=self.width, height=self.height,
                                bg=bg_color, highlightthickness=0)
        self.canvas.pack()
        self.root.protocol("WM_DELETE_WINDOW", self.stop)
        self.root.focus_force()

        # 输入状态
        self._keys_held = set()
        self._mouse_buttons = set()
        self._mouse_x = 0
        self._mouse_y = 0
        self.wheel_delta = 0
        self._after_id = None
        self._running = False

        self._bind_events()

    def _bind_events(self):
        c = self.canvas
        c.bind("<Motion>", self._on_motion)
        c.bind("<ButtonPress>", self._on_down)
        c.bind("<ButtonRelease>", self._on_up)
        c.bind("<MouseWheel>", self._on_wheel)
        r = self.root
        r.bind("<KeyPress>", self._on_key_press)
        r.bind("<KeyRelease>", self._on_key_release)

    def _on_key_press(self, e):
        self._keys_held.add(e.keysym)

    def _on_key_release(self, e):
        self._keys_held.discard(e.keysym)

    def _on_motion(self, e):
        self._mouse_x, self._mouse_y = e.x, e.y

    def _on_down(self, e):
        self._mouse_buttons.add(e.num)

    def _on_up(self, e):
        self._mouse_buttons.discard(e.num)

    def _on_wheel(self, e):
        self.wheel_delta += int(e.delta)

    # ---- 生命周期 ----
    def run_loop(self, tick, frame_delay_ms):
        self._running = True
        self._tick = tick
        self._frame_delay_ms = max(1, int(frame_delay_ms))
        self._after_id = self.root.after(0, self._loop)
        self.root.mainloop()

    def _loop(self):
        if not self._running:
            return
        self._tick()
        if self._running:
            self._after_id = self.root.after(self._frame_delay_ms, self._loop)

    def stop(self):
        self._running = False
        if self._after_id:
            try:
                self.root.after_cancel(self._after_id)
            except Exception:
                pass
        try:
            self.root.quit()
        except Exception:
            pass

    def close(self):
        self.stop()
        try:
            self.root.destroy()
        except Exception:
            pass

    # ---- 每帧 ----
    def pump(self):
        self.root.update()

    def begin_frame(self):
        self.canvas.delete("all")

    def end_frame(self):
        pass

    # ---- 输入 ----
    @property
    def keys_held(self):
        return self._keys_held

    @property
    def mouse_x(self):
        return self._mouse_x

    @property
    def mouse_y(self):
        return self._mouse_y

    @property
    def mouse_buttons(self):
        return self._mouse_buttons

    # ---- 绘制 ----
    def draw_rect(self, x1, y1, x2, y2, color, outline=None, width=1):
        self.canvas.create_rectangle(x1, y1, x2, y2,
                                     fill=color, outline=outline or "")

    def draw_oval(self, x1, y1, x2, y2, color, outline=None, width=1):
        self.canvas.create_oval(x1, y1, x2, y2,
                                fill=color, outline=outline or "")

    def draw_line(self, x1, y1, x2, y2, color, width=2):
        self.canvas.create_line(x1, y1, x2, y2, fill=color, width=max(1, int(width)))

    def draw_polygon(self, points, color, outline=None):
        flat = []
        for px, py in points:
            flat.append(px)
            flat.append(py)
        self.canvas.create_polygon(*flat, fill=color,
                                   outline=outline or color)

    def draw_arc(self, x1, y1, x2, y2, start, extent, color, width=2):
        self.canvas.create_arc(x1, y1, x2, y2, start=start, extent=extent,
                               style="arc", outline=color, width=max(1, int(width)))

    def draw_image(self, x, y, image):
        self.canvas.create_image(x, y, image=image)

    def draw_text(self, x, y, content, color, font, size, weight, slant, anchor):
        self.canvas.create_text(
            x, y, text=content, fill=color,
            font=(font, size, weight, slant), anchor=anchor,
        )


# ======================================================================
# GdiRenderer —— 高性能后端（Windows 专用，自研 GDI 内核）
# ======================================================================

# 虚拟键码 -> gamekit keysym（与 tkinter keysym 一致）
_VK_TO_KEYSYM = {
    0x08: "BackSpace", 0x09: "Tab", 0x0D: "Return", 0x1B: "Escape",
    0x20: "space", 0x21: "Prior", 0x22: "Next", 0x23: "End", 0x24: "Home",
    0x25: "Left", 0x26: "Up", 0x27: "Right", 0x28: "Down",
    0x2E: "Delete", 0x10: "Shift_L", 0x11: "Control_L", 0x12: "Alt_L",
}
_VK_LIST = list(_VK_TO_KEYSYM.keys()) + list(range(0x30, 0x3A)) \
    + list(range(0x41, 0x5B)) + list(range(0x70, 0x7C))  # 0-9, A-Z, F1-F12


def _vk_to_keysym(vk):
    if vk in _VK_TO_KEYSYM:
        return _VK_TO_KEYSYM[vk]
    if 0x30 <= vk <= 0x39:
        return chr(0x30 + (vk - 0x30))
    if 0x41 <= vk <= 0x5A:
        return chr(0x61 + (vk - 0x41))
    if 0x70 <= vk <= 0x7B:
        return "F%d" % (vk - 0x70 + 1)
    return None


class GdiRenderer(Renderer):
    """基于自研 GDI 内核的后端（立即模式）。

    - 渲染：每帧把对象画到后台 Surface（DIB），end_frame 一次性 BitBlt 翻屏
    - 输入：GetAsyncKeyState 轮询键盘 + GetCursorPos 轮询鼠标
    - 文字：GDI CreateFontW / TextOutW（带字体缓存）
    - 仅 Windows 可用；其他平台请用 TkRenderer
    """

    def __init__(self, width, height, title, bg_color):
        from .window import Window
        self.width = int(width)
        self.height = int(height)
        self._bg_rgb = _rgb(str(bg_color))
        self._window = Window(self.width, self.height, title)
        self._screen = self._window.screen
        self._closed = False
        self._fonts = {}          # (family, size, bold, italic) -> HFONT
        self._image_cache = {}    # id(photo) -> Surface（图像精灵像素缓存）
        self._decode_root = None  # 隐藏 tk root，仅用于 PhotoImage 解码
        # 立即创建隐藏 root：Sprite 的 load_image 在 Game.__init__ 之后、
        # run 之前执行，需要默认 root 才能解码 PhotoImage。
        try:
            import tkinter as tk
            self._decode_root = tk.Tk()
            self._decode_root.withdraw()
        except Exception:
            self._decode_root = None

        # 输入状态
        self._keys_held = set()
        self._mouse_buttons = set()
        self._mouse_x = 0
        self._mouse_y = 0
        self.wheel_delta = 0   # 本帧累计滚轮增量（Game 层读取后清零）

    # ---- 生命周期 ----
    def run_loop(self, tick, frame_delay_ms):
        delay = max(0.0, frame_delay_ms / 1000.0)
        while not self._closed:
            self.pump()
            if self._closed:
                break
            tick()
            if delay:
                time.sleep(delay)

    def stop(self):
        self._closed = True

    def close(self):
        self.stop()
        from . import win32
        for hfont in self._fonts.values():
            try:
                win32.gdi32.DeleteObject(hfont)
            except Exception:
                pass
        self._fonts.clear()
        for surf in self._image_cache.values():
            try:
                surf.close()
            except Exception:
                pass
        self._image_cache.clear()
        self._window.close()
        if self._decode_root is not None:
            try:
                self._decode_root.destroy()
            except Exception:
                pass
            self._decode_root = None

    # ---- 每帧 ----
    def pump(self):
        if not self._window.poll_events():
            self._closed = True
        # 键盘轮询
        held = set()
        for vk in _VK_LIST:
            if self._window.is_key_down(vk):
                ks = _vk_to_keysym(vk)
                if ks:
                    held.add(ks)
        self._keys_held = held
        # 鼠标位置
        self._mouse_x, self._mouse_y = self._window.mouse_pos()
        # 鼠标按钮（VK_LBUTTON=1, VK_RBUTTON=2, VK_MBUTTON=4）
        buttons = set()
        if self._window.is_key_down(0x01):
            buttons.add(1)
        if self._window.is_key_down(0x04):
            buttons.add(2)
        if self._window.is_key_down(0x02):
            buttons.add(3)
        self._mouse_buttons = buttons
        # 滚轮（WM_MOUSEWHEEL 累积）
        self.wheel_delta = self._window.wheel_delta
        self._window.reset_wheel()

    def begin_frame(self):
        self._screen.fill(self._bg_rgb)

    def end_frame(self):
        self._window.present()

    # ---- 输入 ----
    @property
    def keys_held(self):
        return self._keys_held

    @property
    def mouse_x(self):
        return self._mouse_x

    @property
    def mouse_y(self):
        return self._mouse_y

    @property
    def mouse_buttons(self):
        return self._mouse_buttons

    # ---- 绘制 ----
    def _hdc(self):
        return self._screen.dc

    def _select_brush(self, color):
        """选择库存画刷并设置颜色，返回画刷句柄（无需删除）。"""
        from . import win32
        hdc = self._hdc()
        win32.gdi32.SelectObject(hdc, win32.gdi32.GetStockObject(win32.DC_BRUSH))
        win32.gdi32.SetDCBrushColor(hdc, _colorref(color))
        return hdc

    def _select_pen(self, color, width):
        """选择库存画笔并设置颜色。返回 hdc（笔是库存对象，无需删除）。"""
        from . import win32
        hdc = self._hdc()
        win32.gdi32.SelectObject(hdc, win32.gdi32.GetStockObject(win32.DC_PEN))
        win32.gdi32.SetDCPenColor(hdc, _colorref(color))
        return hdc

    def draw_rect(self, x1, y1, x2, y2, color, outline=None, width=1):
        from . import win32
        from ctypes import c_long
        if x2 < x1:
            x1, x2 = x2, x1
        if y2 < y1:
            y1, y2 = y2, y1
        hdc = self._select_brush(color)
        rect = (c_long * 4)(int(x1), int(y1), int(x2), int(y2))
        win32.user32.FillRect(hdc, rect, win32.gdi32.GetStockObject(win32.DC_BRUSH))
        if outline and str(outline).lower() not in ("", "none"):
            self.draw_line(x1, y1, x2, y1, outline, width)
            self.draw_line(x2, y1, x2, y2, outline, width)
            self.draw_line(x2, y2, x1, y2, outline, width)
            self.draw_line(x1, y2, x1, y1, outline, width)

    def draw_oval(self, x1, y1, x2, y2, color, outline=None, width=1):
        from . import win32
        hdc = self._select_brush(color)
        # 椭圆描边用同色，避免默认黑边
        pen_color = outline or color
        hdc = self._select_pen(pen_color, width)
        win32.gdi32.Ellipse(hdc, int(x1), int(y1), int(x2), int(y2))

    def draw_line(self, x1, y1, x2, y2, color, width=2):
        from . import win32
        hdc = self._select_pen(color, width)
        win32.gdi32.MoveToEx(hdc, int(x1), int(y1), None)
        win32.gdi32.LineTo(hdc, int(x2), int(y2))

    def draw_polygon(self, points, color, outline=None):
        from . import win32
        from ctypes import c_long
        if not points:
            return
        hdc = self._select_brush(color)
        hdc = self._select_pen(outline or color, 1)
        arr = (c_long * (len(points) * 2))()
        for i, (px, py) in enumerate(points):
            arr[i * 2] = int(px)
            arr[i * 2 + 1] = int(py)
        win32.gdi32.Polygon(hdc, arr, len(points))

    def draw_arc(self, x1, y1, x2, y2, start, extent, color, width=2):
        from . import win32
        import math
        hdc = self._select_pen(color, width)
        cx = (x1 + x2) / 2.0
        cy = (y1 + y2) / 2.0
        rx = max(0.5, (x2 - x1) / 2.0)
        ry = max(0.5, (y2 - y1) / 2.0)
        # GDI Arc 角度：0 度向右，逆时针为正；canvas 是顺时针。换算。
        a0 = math.radians(-start)
        a1 = math.radians(-(start + extent))
        x0 = int(cx + rx * math.cos(a0))
        y0 = int(cy + ry * math.sin(a0))
        x1p = int(cx + rx * math.cos(a1))
        y1p = int(cy + ry * math.sin(a1))
        win32.gdi32.Arc(hdc, int(x1), int(y1), int(x2), int(y2),
                        x0, y0, x1p, y1p)

    def draw_image(self, x, y, image):
        # 图像精灵桥：tkinter PhotoImage -> Surface 像素缓存 -> alpha blit。
        # 首次遇到某张图时做一次像素转换（Python 逐像素，对小图可接受），
        # 之后每帧直接整块位块传送，不再走矢量重绘。
        if image is None:
            return
        if not self._decode_root:
            return
        surf = self._image_cache.get(id(image))
        if surf is None:
            from .surface import Surface
            w, h = image.width(), image.height()
            if w <= 0 or h <= 0:
                return
            surf = Surface(w, h)
            has_trans = hasattr(image, "transparency_get")
            for py in range(h):
                for px in range(w):
                    r, g, b = image.get(px, py)
                    a = 0 if (has_trans and image.transparency_get(px, py)) else 255
                    surf.set_at(px, py, (r, g, b, a))
            self._image_cache[id(image)] = surf
        # canvas.create_image 以 (x, y) 为中心。
        # AlphaBlend 对 top-down DIB 源不工作（实测），这里用软件 alpha 合成：
        # 直接读源 Surface 的 uint32 像素并写入目标 DIB 内存。
        # 精灵图多为 0/255 alpha（PNG 透明背景），快；有半透明时按比例混合。
        from . import win32
        src = surf._buf
        dst = self._screen._buf
        sw, sh = surf.width, surf.height
        ox = int(x - sw / 2)
        oy = int(y - sh / 2)
        W, H = self.width, self.height
        for py in range(sh):
            dy = oy + py
            if dy < 0 or dy >= H:
                continue
            row = dy * W
            srow = py * sw
            for px in range(sw):
                dx = ox + px
                if dx < 0 or dx >= W:
                    continue
                v = src[srow + px]
                a = (v >> 24) & 0xFF
                if a == 0:
                    continue
                if a == 255:
                    dst[row + dx] = v
                else:
                    ov = dst[row + dx]
                    # 预乘合成（SRC_OVER）
                    ia = 255 - a
                    nb = ((v & 0xFF) * a + (ov & 0xFF) * ia) // 255
                    ng = (((v >> 8) & 0xFF) * a + ((ov >> 8) & 0xFF) * ia) // 255
                    nr = (((v >> 16) & 0xFF) * a + ((ov >> 16) & 0xFF) * ia) // 255
                    dst[row + dx] = (nb & 0xFF) | ((ng & 0xFF) << 8) | ((nr & 0xFF) << 16) | 0xFF000000

    # ---- 文字 ----
    def _get_font(self, family, size, bold, slant):
        from . import win32
        key = (family, int(size), bool(bold), bool(slant))
        hfont = self._fonts.get(key)
        if hfont:
            return hfont
        weight = win32.FW_BOLD if bold else win32.FW_NORMAL
        hfont = win32.gdi32.CreateFontW(
            -int(size), 0, 0, 0, weight,
            1 if slant else 0, 0, 0,
            win32.DEFAULT_CHARSET,
            win32.OUT_DEFAULT_PRECIS,
            win32.CLIP_DEFAULT_PRECIS,
            win32.DEFAULT_QUALITY,
            win32.DEFAULT_PITCH | win32.FF_DONTCARE,
            family or "Microsoft YaHei",
        )
        if not hfont:
            hfont = win32.gdi32.CreateFontW(-int(size), 0, 0, 0, weight,
                                            0, 0, 0, win32.DEFAULT_CHARSET,
                                            0, 0, 0, 0, None)
        self._fonts[key] = hfont
        return hfont

    def draw_text(self, x, y, content, color, font, size, weight, slant, anchor):
        from . import win32
        from ctypes import byref
        text = str(content)
        hdc = self._hdc()
        hfont = self._get_font(font, size, weight == "bold", slant == "italic")
        win32.gdi32.SelectObject(hdc, hfont)
        win32.gdi32.SetTextColor(hdc, _colorref(color))
        win32.gdi32.SetBkMode(hdc, win32.TRANSPARENT)
        # 文本尺寸（用于锚点对齐）
        extent = win32.SIZE()
        if text:
            win32.gdi32.GetTextExtentPoint32W(hdc, text, len(text), byref(extent))
        w, h = extent.cx, extent.cy
        ax, ay = 0, 0
        if anchor in ("center", "n", "s"):
            ax = -w // 2
        elif anchor in ("ne", "e", "se"):
            ax = -w
        if anchor in ("w", "center", "e"):
            ay = -h // 2
        elif anchor in ("sw", "s", "se"):
            ay = -h
        win32.gdi32.TextOutW(hdc, int(x) + ax, int(y) + ay, text, len(text))

