"""audio：WAV 音效与音乐（Windows winsound，零第三方依赖）。"""
