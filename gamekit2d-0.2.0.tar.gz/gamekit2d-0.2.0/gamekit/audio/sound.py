"""音频模块：WAV 音效与背景音乐。

实现说明（零第三方依赖）：
- Windows 平台使用标准库 ``winsound`` 异步播放 WAV 文件
- 其他平台（Linux / macOS）标准库没有音频播放能力，
  ``Sound.play()`` 会打印提示并静默，不影响游戏逻辑运行

限制：
- 仅支持 ``.wav`` 文件（标准库只能解码 wav）
- Windows 下一次只能播放一个音频（winsound 限制），
  音乐与音效无法同时响，按需取舍
"""

import os
import sys

_WIN = sys.platform == "win32"
if _WIN:
    import winsound

    _HAS_AUDIO = True
else:
    _HAS_AUDIO = False


class Sound:
    """一个 WAV 音频。

    :param path: .wav 文件路径
    :param volume: 音量 0.0 ~ 1.0（winsound 不支持调音量，仅作记录保留）
    :param loop: 是否循环播放
    """

    def __init__(self, path, volume=1.0, loop=False):
        if not os.path.exists(path):
            raise FileNotFoundError("音频文件不存在: %s" % path)
        if not path.lower().endswith(".wav"):
            raise ValueError(
                "gamekit 音频仅支持 .wav 文件（标准库能力限制），收到: %s" % path
            )
        self.path = path
        self.volume = max(0.0, min(1.0, float(volume)))
        self._looping = bool(loop)
        self._playing = False

    @property
    def playing(self):
        return self._playing

    def play(self, loop=None):
        """播放音频。``loop=True`` 循环播放，``loop=False`` 播放一次。"""
        if not _HAS_AUDIO:
            print("[gamekit] 当前平台不支持音频播放（仅 Windows 支持）: %s" % self.path)
            return self
        if loop is not None:
            self._looping = bool(loop)
        flags = winsound.SND_FILENAME | winsound.SND_ASYNC
        if self._looping:
            flags |= winsound.SND_LOOP
        winsound.PlaySound(self.path, flags)
        self._playing = True
        return self

    def stop(self):
        """停止播放。"""
        if _HAS_AUDIO:
            winsound.PlaySound(None, winsound.SND_PURGE)
        self._playing = False
        return self
