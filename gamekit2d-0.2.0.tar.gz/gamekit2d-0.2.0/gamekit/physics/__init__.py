"""physics：碰撞检测与物理。"""
